📍 Catatan Penting

⚠️ Untuk Pengguna Data Pajak atau Administratif Lokal
Kode wilayah dalam data ini mungkin sedikit berbeda dengan yang digunakan di sistem pajak atau sistem administrasi daerah tertentu. 
Anda bisa menyesuaikannya dengan referensi kode wilayah resmi yang berlaku di masing-masing daerah.

⚠️ Kami tidak bertanggung jawab jika ada ketidaksesuaian data dengan kondisi batas wilayah di lapangan.
⚠️ Penggunaan data ini sepenuhnya menjadi tanggung jawab masing-masing pengguna. Harap digunakan secara bijak.

Jika ada pihak yang merasa keberatan atau dirugikan atas pembagian data ini, silakan hubungi saya lewat email:
📧 zegote@gmail.com
